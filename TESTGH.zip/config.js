module.exports = {
  ownerNumber: ["6281327751879", "6285180972835"],
  ownerName: "RadenDev",
  botNumber: "6285641822587",
  botName: "Bot Raden V1",
  botVersion: "1.0.0",
  load: "*_Loading..._*",
  data: "*_Loading Data..._*",
  gagal: "*_Maaf Terjadi Eror_*",
  systemerr: "*_Maaf Kesalahan Sistem, Coba Lagi_*",
  linkerr: "*_Masukan Link Yang Benar!_*",
  usererr: "*_Masukan Username Yang Benar!_*",
  dataerr: "*_Terjadi Kesalahan Saat Mengambil Data_*",
  groupOnly: "*_Fitur Khusus Grup!_*",
  adminOnly: "*_Fitur Khusus Admin!_*",
  ownerOnly: "*_Fitur Khusus Raden!_*",
  privatOnly: "*_Fitur Khusus Chat Pribadi_*",
  botAdmin: "*_Bot Harus Menjadi Admin!_*"
}